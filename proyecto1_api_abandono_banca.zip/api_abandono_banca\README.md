# API de predicción de abandono bancario

Aplicación FastAPI con preprocesamiento determinista, modelo KNN y frontend responsive.

## Ejecución local

```bash
python -m pip install -r requirements.txt
python -m uvicorn main:app --reload --port 8000
```

- Interfaz web: <http://127.0.0.1:8000/>
- Swagger UI: <http://127.0.0.1:8000/docs>

## Uso

1. Abre `/`.
2. Introduce los datos del cliente o conserva los valores de ejemplo.
3. Pulsa **Calcular riesgo**.
4. Consulta la clase, la probabilidad, el nivel de riesgo y la acción recomendada.

También puedes probar `POST /predict` desde `/docs` con el JSON de ejemplo mostrado automáticamente por Swagger.

## Despliegue en Render

1. Crea un repositorio con el contenido de esta carpeta.
2. En Render, selecciona **New > Blueprint** y usa `render.yaml`.
3. Espera a que termine el build con Python 3.11 y Scikit-learn 1.6.1.
4. Registra la URL pública generada por Render en este documento.

### URL pública de producción

https://api-abandono-banca.onrender.com

### Uso público

- Interfaz web: https://api-abandono-banca.onrender.com/
- Documentación Swagger: https://api-abandono-banca.onrender.com/docs
- Esquema OpenAPI: https://api-abandono-banca.onrender.com/openapi.json
- Endpoint de inferencia: `POST https://api-abandono-banca.onrender.com/predict`

### Captura de producción

![Inferencia real en la interfaz de riesgo de abandono](captura-produccion.png)

Captura obtenida ejecutando el formulario con el cliente `CLI-8492`; el resultado mostrado corresponde a una inferencia real del modelo KNN.

## Repositorio GitHub

https://github.com/jorgelerr7-commits/api-abandono-banca

## Artefactos

Los archivos `artifacts/preprocesador_banca.joblib` y `artifacts/modelo_knn.joblib` deben conservarse en el repositorio y no deben modificarse.
